--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)
-- Dumped by pg_dump version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ems_local;
--
-- Name: ems_local; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ems_local WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_IN';


ALTER DATABASE ems_local OWNER TO postgres;

\connect ems_local

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: employee_designation_create(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.employee_designation_create(p_name character varying, p_desc character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    res INTEGER;
BEGIN
    -- Insert into the User table
    INSERT INTO employee_designation(created_at, modified_at, is_deleted, name, description)
    VALUES (CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, FALSE, p_name, p_desc)
    RETURNING id INTO res;

    RETURN res;
END;
$$;


ALTER FUNCTION public.employee_designation_create(p_name character varying, p_desc character varying) OWNER TO postgres;

--
-- Name: employee_designation_delete(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.employee_designation_delete(p_designation_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM employee_designation
    WHERE employee_designation.id = p_designation_id;

    -- Check if any rows were affected
    IF FOUND THEN
        RETURN TRUE; -- Successful deletion
    ELSE
        RETURN FALSE; -- No rows were deleted (designation not found)
    END IF;
END;
$$;


ALTER FUNCTION public.employee_designation_delete(p_designation_id integer) OWNER TO postgres;

--
-- Name: employee_designation_list(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.employee_designation_list() RETURNS TABLE(id bigint, name character varying, description text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        employee_designation.id,
        employee_designation.name,
        employee_designation.description
    FROM employee_designation;
    RETURN;
END;
$$;


ALTER FUNCTION public.employee_designation_list() OWNER TO postgres;

--
-- Name: employee_designation_retreive(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.employee_designation_retreive(p_designation_id integer) RETURNS TABLE(id bigint, name character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
		employee_designation.id,
		employee_designation.name
	FROM employee_designation
    WHERE employee_designation.id = p_designation_id;
    RETURN;
END;
$$;


ALTER FUNCTION public.employee_designation_retreive(p_designation_id integer) OWNER TO postgres;

--
-- Name: employee_designation_update(integer, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.employee_designation_update(p_designation_id integer, p_name character varying, p_desc character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    res INTEGER;
BEGIN
    -- Update the employee_designation table
    UPDATE employee_designation
    SET modified_at = CURRENT_TIMESTAMP, name = p_name, description = p_desc
    WHERE id = p_designation_id
    RETURNING id INTO res;

    -- Check if the update was successful
    IF res IS NOT NULL THEN
        RETURN res;
    ELSE
        -- Handle the case where the update didn't affect any rows (designation_id not found)
        RETURN -1;  -- or any other value to indicate failure
    END IF;
END;
$$;


ALTER FUNCTION public.employee_designation_update(p_designation_id integer, p_name character varying, p_desc character varying) OWNER TO postgres;

--
-- Name: employee_designations_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.employee_designations_count() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    total INTEGER;
BEGIN
    SELECT COUNT(*) INTO total FROM employee_designation;
	RETURN total;
END;
$$;


ALTER FUNCTION public.employee_designations_count() OWNER TO postgres;

--
-- Name: employee_document_create(integer, character varying, character varying, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.employee_document_create(p_employee_id integer, p_file_name character varying, p_type character varying, p_is_verified boolean) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
	new_doc jsonb;
BEGIN
    INSERT INTO public.employee_document(created_at, modified_at, is_deleted, employee_id, file, type, is_verified)
    VALUES (
		NOW(),
		NOW(),
		FALSE,
        p_employee_id,
        p_file_name,
        p_type,
        p_is_verified
    )
	RETURNING 
        to_jsonb(employee_document) INTO new_doc;

    RETURN new_doc;
END;
$$;


ALTER FUNCTION public.employee_document_create(p_employee_id integer, p_file_name character varying, p_type character varying, p_is_verified boolean) OWNER TO postgres;

--
-- Name: employee_employee_create(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.employee_employee_create(p_username character varying, p_password character varying, p_first_name character varying, p_last_name character varying, p_email character varying, p_phone character varying, p_address character varying, p_role character varying, p_dp_url character varying, p_designation_id integer, p_department_id integer) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$

DECLARE
    v_user_id INT;
    v_employee_id INT;
    v_result JSONB;
BEGIN
    -- Create User
    INSERT INTO core_user (
        username, password, first_name, last_name, email, phone, address, role, dp,
        is_active, is_staff, is_superuser, last_login, date_joined
    )
    VALUES (
        p_username, p_password, p_first_name, p_last_name, p_email, p_phone, p_address,
        p_role, p_dp_url, true, false, false, NOW(), NOW()
    )
    RETURNING id INTO v_user_id;

    -- Create Employee
    INSERT INTO employee_employee (created_at, modified_at, is_deleted, user_id, designation_id, department_id)
    VALUES (NOW(), NOW(), FALSE, v_user_id, p_designation_id, p_department_id)
    RETURNING id INTO v_employee_id;

    -- Construct Result JSONB
    SELECT jsonb_build_object(
        'user_id', v_user_id,
        'employee_id', v_employee_id,
        'username', p_username,
        'first_name', p_first_name,
        'last_name', p_last_name,
        'email', p_email,
        'phone', p_phone,
        'address', p_address,
        'role', p_role,
        'dp_url', p_dp_url,
        'designation_id', p_designation_id,
        'department_id', p_department_id
    ) INTO v_result;

    RETURN v_result;
END;
$$;


ALTER FUNCTION public.employee_employee_create(p_username character varying, p_password character varying, p_first_name character varying, p_last_name character varying, p_email character varying, p_phone character varying, p_address character varying, p_role character varying, p_dp_url character varying, p_designation_id integer, p_department_id integer) OWNER TO postgres;

--
-- Name: employee_employee_list(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.employee_employee_list(search_var text DEFAULT NULL::text) RETURNS SETOF jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
BEGIN
    -- Fetch Employee Data with User Details
	RETURN QUERY
    SELECT jsonb_build_object(
        'user_id', u.id,
        'username', u.username,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'email', u.email,
        'phone', u.phone,
        'address', u.address,
        'role', u.role,
        'dp_url', u.dp,
        'designation_id', e.designation_id,
        'department_id', e.department_id,
		'documents', (
            SELECT jsonb_agg(jsonb_build_object(
                'document_id', d.id,
                'file', d.file,
                'type', d.type,
                'is_verified', d.is_verified
            ))
            FROM public.employee_document d
            WHERE d.employee_id = e.id
        )
    )
    FROM employee_employee e
    JOIN core_user u ON e.user_id = u.id
    WHERE (search_var IS NULL OR search_var = '' OR u.email ILIKE '%' || search_var || '%');

    RETURN;
END;
$$;


ALTER FUNCTION public.employee_employee_list(search_var text) OWNER TO postgres;

--
-- Name: task_attachment_create(character varying, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.task_attachment_create(p_file character varying, p_task_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_attachment jsonb;
BEGIN
    INSERT INTO task_attachment(
        created_at,
        modified_at,
        is_deleted,
        file,
        task_id
    ) VALUES (
        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP,
        FALSE,
        p_file,
        p_task_id
    )
    RETURNING 
        to_jsonb(task_attachment) INTO new_attachment;
    
    RETURN new_attachment;
END;
$$;


ALTER FUNCTION public.task_attachment_create(p_file character varying, p_task_id bigint) OWNER TO postgres;

--
-- Name: task_attachment_delete(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.task_attachment_delete(p_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM task_attachment
    WHERE id = p_id;
    
    RETURN FOUND;  -- Returns true if a row was found and deleted, false otherwise
END;
$$;


ALTER FUNCTION public.task_attachment_delete(p_id bigint) OWNER TO postgres;

--
-- Name: task_attachment_retrieve(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.task_attachment_retrieve(p_task_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    attachment_data jsonb;
BEGIN
    SELECT 
        to_jsonb(task_attachment) INTO attachment_data
    FROM task_attachment
    WHERE task_attachment.id = p_task_id;
    
    RETURN attachment_data;
END;
$$;


ALTER FUNCTION public.task_attachment_retrieve(p_task_id bigint) OWNER TO postgres;

--
-- Name: task_attachment_update(bigint, character varying, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.task_attachment_update(p_id bigint, p_file character varying, p_task_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    updated_attachment jsonb;
BEGIN
    UPDATE task_attachment AS ta
    SET
        modified_at = CURRENT_TIMESTAMP,
        file = p_file,
        task_id = p_task_id
    FROM task_attachment
    WHERE ta.id = p_id
    RETURNING 
        to_jsonb(ta) INTO updated_attachment;

    RETURN updated_attachment;
END;
$$;


ALTER FUNCTION public.task_attachment_update(p_id bigint, p_file character varying, p_task_id bigint) OWNER TO postgres;

--
-- Name: task_task_create(character varying, text, double precision, timestamp with time zone, timestamp with time zone, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.task_task_create(p_title character varying, p_desc text, p_eta double precision, st timestamp with time zone, et timestamp with time zone, p_emp_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_task jsonb;
BEGIN
    -- Insert into the Task table and return the inserted row as jsonb
    INSERT INTO task_task(
        created_at,
        modified_at,
        is_deleted,
        title,
        description,
        eta,
        start_time,
        end_time,
        employee_id
    )
    VALUES (
        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP,
        FALSE,
        p_title,
        p_desc,
        p_eta,
        st,
        et,
        p_emp_id
    )
    RETURNING 
        to_jsonb(task_task) INTO new_task;

    RETURN new_task;
END;
$$;


ALTER FUNCTION public.task_task_create(p_title character varying, p_desc text, p_eta double precision, st timestamp with time zone, et timestamp with time zone, p_emp_id bigint) OWNER TO postgres;

--
-- Name: task_task_delete(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.task_task_delete(p_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM task_task
    WHERE id = p_id;
    
    RETURN FOUND;  -- Returns true if a row was found and deleted, false otherwise
END;
$$;


ALTER FUNCTION public.task_task_delete(p_id bigint) OWNER TO postgres;

--
-- Name: task_task_list(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.task_task_list(search_var text DEFAULT NULL::text) RETURNS SETOF jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
BEGIN
    RETURN QUERY
    SELECT jsonb_build_object(
        'id', task_task.id,
        'created_at', task_task.created_at,
        'title', task_task.title,
        'description', task_task.description,
        'eta', task_task.eta,
        'start_time', task_task.start_time,
        'end_time', task_task.end_time,
        'employee_id', task_task.employee_id,
        'attachments', (
            SELECT jsonb_agg(jsonb_build_object(
                'id', attachment.id,
                'file', attachment.file
            ))
            FROM task_attachment as attachment
            WHERE attachment.task_id = task_task.id
        )
    )
    FROM task_task
    WHERE (search_var IS NULL OR search_var = '' OR task_task.title ILIKE '%' || search_var || '%');
    RETURN;
END;
$$;


ALTER FUNCTION public.task_task_list(search_var text) OWNER TO postgres;

--
-- Name: task_task_retrieve(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.task_task_retrieve(p_id bigint) RETURNS SETOF jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
BEGIN
	RETURN QUERY
    SELECT jsonb_build_object(
			'id', task_task.id,
			'created_at', task_task.created_at,
			'title', task_task.title,
			'description', task_task.description,
			'eta', task_task.eta,
			'start_time', task_task.start_time,
			'end_time', task_task.end_time,
			'employee_id', task_task.employee_id
		)
    FROM task_task
	WHERE task_task.id = p_id;
    RETURN;
END;
$$;


ALTER FUNCTION public.task_task_retrieve(p_id bigint) OWNER TO postgres;

--
-- Name: task_task_update(bigint, character varying, text, double precision, timestamp with time zone, timestamp with time zone, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.task_task_update(p_id bigint, p_title character varying, p_description text, p_eta double precision, p_start_time timestamp with time zone, p_end_time timestamp with time zone, p_employee_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    ret_result jsonb;
BEGIN
    UPDATE task_task AS tt
    SET
        title = p_title,
        description = p_description,
        eta = p_eta,
        start_time = p_start_time,
        end_time = p_end_time,
        employee_id = p_employee_id
    FROM task_task
    WHERE tt.id = p_id
    RETURNING 
        to_jsonb(tt) INTO ret_result;

    RETURN ret_result;
END;
$$;


ALTER FUNCTION public.task_task_update(p_id bigint, p_title character varying, p_description text, p_eta double precision, p_start_time timestamp with time zone, p_end_time timestamp with time zone, p_employee_id bigint) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    phone character varying(32),
    address character varying(64),
    role character varying(200),
    dp character varying(100) NOT NULL
);


ALTER TABLE public.core_user OWNER TO postgres;

--
-- Name: core_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.core_user_groups OWNER TO postgres;

--
-- Name: core_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.core_user_user_permissions OWNER TO postgres;

--
-- Name: core_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: department_department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.department_department (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_deleted boolean NOT NULL,
    name character varying(254) NOT NULL,
    type_id bigint NOT NULL,
    description character varying(50)
);


ALTER TABLE public.department_department OWNER TO postgres;

--
-- Name: department_department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.department_department ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.department_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: department_departmenttype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.department_departmenttype (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(50) NOT NULL
);


ALTER TABLE public.department_departmenttype OWNER TO postgres;

--
-- Name: department_departmenttype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.department_departmenttype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.department_departmenttype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: employee_designation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_designation (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_deleted boolean NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.employee_designation OWNER TO postgres;

--
-- Name: employee_designation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.employee_designation ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.employee_designation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: employee_document; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_document (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_deleted boolean NOT NULL,
    file character varying(100) NOT NULL,
    type character varying(32) NOT NULL,
    is_verified boolean NOT NULL,
    employee_id bigint NOT NULL
);


ALTER TABLE public.employee_document OWNER TO postgres;

--
-- Name: employee_document_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.employee_document ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.employee_document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: employee_employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_employee (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_deleted boolean NOT NULL,
    extra_data jsonb,
    department_id bigint NOT NULL,
    designation_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.employee_employee OWNER TO postgres;

--
-- Name: employee_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.employee_employee ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.employee_employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: employee_salaryrecord; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_salaryrecord (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_deleted boolean NOT NULL,
    amount character varying(50) NOT NULL,
    paid_date timestamp with time zone NOT NULL,
    is_paid boolean NOT NULL,
    department_id bigint NOT NULL,
    employee_id bigint NOT NULL
);


ALTER TABLE public.employee_salaryrecord OWNER TO postgres;

--
-- Name: employee_salaryrecord_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.employee_salaryrecord ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.employee_salaryrecord_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: task_attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_attachment (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_deleted boolean NOT NULL,
    file character varying(100) NOT NULL,
    task_id bigint NOT NULL
);


ALTER TABLE public.task_attachment OWNER TO postgres;

--
-- Name: task_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.task_attachment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.task_attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: task_task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_task (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_deleted boolean NOT NULL,
    title character varying(50),
    description text NOT NULL,
    eta double precision NOT NULL,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    employee_id bigint NOT NULL
);


ALTER TABLE public.task_task OWNER TO postgres;

--
-- Name: task_task_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.task_task ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.task_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3572.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3574.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3576.dat';

--
-- Data for Name: core_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, phone, address, role, dp) FROM stdin;
\.
COPY public.core_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, phone, address, role, dp) FROM '$$PATH$$/3578.dat';

--
-- Data for Name: core_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.core_user_groups (id, user_id, group_id) FROM '$$PATH$$/3579.dat';

--
-- Data for Name: core_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.core_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3582.dat';

--
-- Data for Name: department_department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.department_department (id, created_at, modified_at, is_deleted, name, type_id, description) FROM stdin;
\.
COPY public.department_department (id, created_at, modified_at, is_deleted, name, type_id, description) FROM '$$PATH$$/3584.dat';

--
-- Data for Name: department_departmenttype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.department_departmenttype (id, name, description) FROM stdin;
\.
COPY public.department_departmenttype (id, name, description) FROM '$$PATH$$/3586.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3588.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3590.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3592.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3594.dat';

--
-- Data for Name: employee_designation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_designation (id, created_at, modified_at, is_deleted, name, description) FROM stdin;
\.
COPY public.employee_designation (id, created_at, modified_at, is_deleted, name, description) FROM '$$PATH$$/3595.dat';

--
-- Data for Name: employee_document; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_document (id, created_at, modified_at, is_deleted, file, type, is_verified, employee_id) FROM stdin;
\.
COPY public.employee_document (id, created_at, modified_at, is_deleted, file, type, is_verified, employee_id) FROM '$$PATH$$/3597.dat';

--
-- Data for Name: employee_employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_employee (id, created_at, modified_at, is_deleted, extra_data, department_id, designation_id, user_id) FROM stdin;
\.
COPY public.employee_employee (id, created_at, modified_at, is_deleted, extra_data, department_id, designation_id, user_id) FROM '$$PATH$$/3599.dat';

--
-- Data for Name: employee_salaryrecord; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_salaryrecord (id, created_at, modified_at, is_deleted, amount, paid_date, is_paid, department_id, employee_id) FROM stdin;
\.
COPY public.employee_salaryrecord (id, created_at, modified_at, is_deleted, amount, paid_date, is_paid, department_id, employee_id) FROM '$$PATH$$/3601.dat';

--
-- Data for Name: task_attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_attachment (id, created_at, modified_at, is_deleted, file, task_id) FROM stdin;
\.
COPY public.task_attachment (id, created_at, modified_at, is_deleted, file, task_id) FROM '$$PATH$$/3603.dat';

--
-- Data for Name: task_task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_task (id, created_at, modified_at, is_deleted, title, description, eta, start_time, end_time, employee_id) FROM stdin;
\.
COPY public.task_task (id, created_at, modified_at, is_deleted, title, description, eta, start_time, end_time, employee_id) FROM '$$PATH$$/3605.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 56, true);


--
-- Name: core_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_user_groups_id_seq', 1, false);


--
-- Name: core_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_user_id_seq', 11, true);


--
-- Name: core_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_user_user_permissions_id_seq', 1, false);


--
-- Name: department_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.department_department_id_seq', 3, true);


--
-- Name: department_departmenttype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.department_departmenttype_id_seq', 3, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 21, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 14, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 25, true);


--
-- Name: employee_designation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_designation_id_seq', 7, true);


--
-- Name: employee_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_document_id_seq', 5, true);


--
-- Name: employee_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_employee_id_seq', 5, true);


--
-- Name: employee_salaryrecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_salaryrecord_id_seq', 1, false);


--
-- Name: task_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_attachment_id_seq', 9, true);


--
-- Name: task_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_task_id_seq', 9, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: core_user_groups core_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_pkey PRIMARY KEY (id);


--
-- Name: core_user_groups core_user_groups_user_id_group_id_c82fcad1_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_user_id_group_id_c82fcad1_uniq UNIQUE (user_id, group_id);


--
-- Name: core_user core_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user
    ADD CONSTRAINT core_user_pkey PRIMARY KEY (id);


--
-- Name: core_user_user_permissions core_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: core_user_user_permissions core_user_user_permissions_user_id_permission_id_73ea0daa_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permissions_user_id_permission_id_73ea0daa_uniq UNIQUE (user_id, permission_id);


--
-- Name: core_user core_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user
    ADD CONSTRAINT core_user_username_key UNIQUE (username);


--
-- Name: department_department department_department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department_department
    ADD CONSTRAINT department_department_pkey PRIMARY KEY (id);


--
-- Name: department_departmenttype department_departmenttype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department_departmenttype
    ADD CONSTRAINT department_departmenttype_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: employee_designation employee_designation_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_designation
    ADD CONSTRAINT employee_designation_name_key UNIQUE (name);


--
-- Name: employee_designation employee_designation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_designation
    ADD CONSTRAINT employee_designation_pkey PRIMARY KEY (id);


--
-- Name: employee_document employee_document_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_document
    ADD CONSTRAINT employee_document_pkey PRIMARY KEY (id);


--
-- Name: employee_employee employee_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_employee
    ADD CONSTRAINT employee_employee_pkey PRIMARY KEY (id);


--
-- Name: employee_employee employee_employee_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_employee
    ADD CONSTRAINT employee_employee_user_id_key UNIQUE (user_id);


--
-- Name: employee_salaryrecord employee_salaryrecord_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_salaryrecord
    ADD CONSTRAINT employee_salaryrecord_pkey PRIMARY KEY (id);


--
-- Name: task_attachment task_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_attachment
    ADD CONSTRAINT task_attachment_pkey PRIMARY KEY (id);


--
-- Name: task_task task_task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_task
    ADD CONSTRAINT task_task_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: core_user_groups_group_id_fe8c697f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_groups_group_id_fe8c697f ON public.core_user_groups USING btree (group_id);


--
-- Name: core_user_groups_user_id_70b4d9b8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_groups_user_id_70b4d9b8 ON public.core_user_groups USING btree (user_id);


--
-- Name: core_user_user_permissions_permission_id_35ccf601; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_user_permissions_permission_id_35ccf601 ON public.core_user_user_permissions USING btree (permission_id);


--
-- Name: core_user_user_permissions_user_id_085123d3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_user_permissions_user_id_085123d3 ON public.core_user_user_permissions USING btree (user_id);


--
-- Name: core_user_username_36e4f7f7_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_username_36e4f7f7_like ON public.core_user USING btree (username varchar_pattern_ops);


--
-- Name: department_department_created_at_a7255951; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX department_department_created_at_a7255951 ON public.department_department USING btree (created_at);


--
-- Name: department_department_modified_at_be8968b7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX department_department_modified_at_be8968b7 ON public.department_department USING btree (modified_at);


--
-- Name: department_department_type_id_b13c836b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX department_department_type_id_b13c836b ON public.department_department USING btree (type_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: employee_designation_created_at_812ac73e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_designation_created_at_812ac73e ON public.employee_designation USING btree (created_at);


--
-- Name: employee_designation_modified_at_a2258fa8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_designation_modified_at_a2258fa8 ON public.employee_designation USING btree (modified_at);


--
-- Name: employee_designation_name_f3e48851_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_designation_name_f3e48851_like ON public.employee_designation USING btree (name varchar_pattern_ops);


--
-- Name: employee_document_created_at_00ced4c9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_document_created_at_00ced4c9 ON public.employee_document USING btree (created_at);


--
-- Name: employee_document_employee_id_db3d2351; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_document_employee_id_db3d2351 ON public.employee_document USING btree (employee_id);


--
-- Name: employee_document_modified_at_eeef5319; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_document_modified_at_eeef5319 ON public.employee_document USING btree (modified_at);


--
-- Name: employee_employee_created_at_32e120bd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_employee_created_at_32e120bd ON public.employee_employee USING btree (created_at);


--
-- Name: employee_employee_department_id_8fce1a05; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_employee_department_id_8fce1a05 ON public.employee_employee USING btree (department_id);


--
-- Name: employee_employee_designation_id_c8b301b9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_employee_designation_id_c8b301b9 ON public.employee_employee USING btree (designation_id);


--
-- Name: employee_employee_modified_at_662edc18; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_employee_modified_at_662edc18 ON public.employee_employee USING btree (modified_at);


--
-- Name: employee_salaryrecord_created_at_2b6cc799; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_salaryrecord_created_at_2b6cc799 ON public.employee_salaryrecord USING btree (created_at);


--
-- Name: employee_salaryrecord_department_id_64eab0b9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_salaryrecord_department_id_64eab0b9 ON public.employee_salaryrecord USING btree (department_id);


--
-- Name: employee_salaryrecord_employee_id_1559f2df; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_salaryrecord_employee_id_1559f2df ON public.employee_salaryrecord USING btree (employee_id);


--
-- Name: employee_salaryrecord_modified_at_e78de87f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_salaryrecord_modified_at_e78de87f ON public.employee_salaryrecord USING btree (modified_at);


--
-- Name: task_attachment_created_at_fd57aa0e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_attachment_created_at_fd57aa0e ON public.task_attachment USING btree (created_at);


--
-- Name: task_attachment_modified_at_8eafca8a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_attachment_modified_at_8eafca8a ON public.task_attachment USING btree (modified_at);


--
-- Name: task_attachment_task_id_ed7e7f02; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_attachment_task_id_ed7e7f02 ON public.task_attachment USING btree (task_id);


--
-- Name: task_task_created_at_51f30398; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_task_created_at_51f30398 ON public.task_task USING btree (created_at);


--
-- Name: task_task_employee_id_62e95cde; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_task_employee_id_62e95cde ON public.task_task USING btree (employee_id);


--
-- Name: task_task_modified_at_8098b051; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_task_modified_at_8098b051 ON public.task_task USING btree (modified_at);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_groups core_user_groups_group_id_fe8c697f_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_group_id_fe8c697f_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_groups core_user_groups_user_id_70b4d9b8_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_user_id_70b4d9b8_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_user_permissions core_user_user_permi_permission_id_35ccf601_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permi_permission_id_35ccf601_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_user_permissions core_user_user_permissions_user_id_085123d3_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permissions_user_id_085123d3_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: department_department department_departmen_type_id_b13c836b_fk_departmen; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department_department
    ADD CONSTRAINT department_departmen_type_id_b13c836b_fk_departmen FOREIGN KEY (type_id) REFERENCES public.department_departmenttype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: employee_document employee_document_employee_id_db3d2351_fk_employee_employee_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_document
    ADD CONSTRAINT employee_document_employee_id_db3d2351_fk_employee_employee_id FOREIGN KEY (employee_id) REFERENCES public.employee_employee(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: employee_employee employee_employee_department_id_8fce1a05_fk_departmen; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_employee
    ADD CONSTRAINT employee_employee_department_id_8fce1a05_fk_departmen FOREIGN KEY (department_id) REFERENCES public.department_department(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: employee_employee employee_employee_designation_id_c8b301b9_fk_employee_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_employee
    ADD CONSTRAINT employee_employee_designation_id_c8b301b9_fk_employee_ FOREIGN KEY (designation_id) REFERENCES public.employee_designation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: employee_employee employee_employee_user_id_2dd26fdc_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_employee
    ADD CONSTRAINT employee_employee_user_id_2dd26fdc_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: employee_salaryrecord employee_salaryrecor_department_id_64eab0b9_fk_departmen; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_salaryrecord
    ADD CONSTRAINT employee_salaryrecor_department_id_64eab0b9_fk_departmen FOREIGN KEY (department_id) REFERENCES public.department_department(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: employee_salaryrecord employee_salaryrecor_employee_id_1559f2df_fk_employee_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_salaryrecord
    ADD CONSTRAINT employee_salaryrecor_employee_id_1559f2df_fk_employee_ FOREIGN KEY (employee_id) REFERENCES public.employee_employee(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: task_attachment task_attachment_task_id_ed7e7f02_fk_task_task_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_attachment
    ADD CONSTRAINT task_attachment_task_id_ed7e7f02_fk_task_task_id FOREIGN KEY (task_id) REFERENCES public.task_task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: task_task task_task_employee_id_62e95cde_fk_employee_employee_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_task
    ADD CONSTRAINT task_task_employee_id_62e95cde_fk_employee_employee_id FOREIGN KEY (employee_id) REFERENCES public.employee_employee(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

